package nl.knaw.huygens.persistence;

public interface PersistenceManager {

  /**
   * @param url the URL to persist
   * @return persistentId
   * @throws PersistenceException
   */
  String persistURL(String url) throws PersistenceException;

  /**
   * Get the url value of the Handle that is persisted.
   * @param persistentId
   * @return URL that the persistentId refers to
   * @throws PersistenceException
   */
  String getPersistedURL(String persistentId) throws PersistenceException;

  /**
   * Get the url to the Handle see http://handle.net/factsheet.html
   * @param persistentId
   * @return
   * @throws PersistenceException
   */
  String getPersistentURL(String persistentId);

  /**
   * @param persistentId the persistentId to delete
   * @throws PersistenceException
   */
  void deletePersistentId(String persistentId) throws PersistenceException;

  /**
   * @param persistentId the pid to change the value of
   * @param url the new value for persistentId to refer to
   * @throws PersistenceException
   */
  void modifyURLForPersistentId(String persistentId, String url) throws PersistenceException;

}
