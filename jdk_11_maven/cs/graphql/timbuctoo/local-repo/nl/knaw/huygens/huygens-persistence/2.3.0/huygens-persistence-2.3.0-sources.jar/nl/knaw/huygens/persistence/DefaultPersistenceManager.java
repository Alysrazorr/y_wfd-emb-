package nl.knaw.huygens.persistence;

import java.util.UUID;

/**
 * This PersistenceManager implementation simply creates a unique id.
 * However, this id is not registered anywhere...
 */
public class DefaultPersistenceManager implements PersistenceManager {

  @Override
  public String persistURL(String url) throws PersistenceException {
    return createId();
  }

  @Override
  public String getPersistedURL(String persistentId) throws PersistenceException {
    return createUrl(persistentId);
  }

  protected String createId() {
    return UUID.randomUUID().toString();
  }

  @Override
  public void deletePersistentId(String persistentId) throws PersistenceException {}

  @Override
  public void modifyURLForPersistentId(String persistentId, String url) throws PersistenceException {}

  @Override
  public String getPersistentURL(String persistentId) {
    return createUrl(persistentId);
  }

  private String createUrl(String persistentId) {
    return String.format("http://example.com/%s", persistentId);
  }

}
