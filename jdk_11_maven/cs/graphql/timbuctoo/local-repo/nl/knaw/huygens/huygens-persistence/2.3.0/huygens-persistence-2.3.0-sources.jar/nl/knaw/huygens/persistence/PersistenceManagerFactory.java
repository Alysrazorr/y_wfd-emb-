package nl.knaw.huygens.persistence;

public class PersistenceManagerFactory {

  public static PersistenceManager newPersistenceManager(boolean handleEnabled, String cipher, String namingAuthority, String prefix, String pathToPrivateKey)
      throws PersistenceManagerCreationException {
    if (handleEnabled) {
      return HandleManager.newHandleManager(cipher, namingAuthority, prefix, pathToPrivateKey);
    } else {
      return new DefaultPersistenceManager();
    }
  }

}
