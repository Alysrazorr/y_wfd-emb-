package nl.knaw.huygens.persistence;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.security.PrivateKey;

import net.handle.hdllib.AbstractResponse;
import net.handle.hdllib.AdminRecord;
import net.handle.hdllib.AuthenticationInfo;
import net.handle.hdllib.ClientSessionTracker;
import net.handle.hdllib.Common;
import net.handle.hdllib.CreateHandleRequest;
import net.handle.hdllib.DeleteHandleRequest;
import net.handle.hdllib.Encoder;
import net.handle.hdllib.HandleException;
import net.handle.hdllib.HandleResolver;
import net.handle.hdllib.HandleValue;
import net.handle.hdllib.ModifyValueRequest;
import net.handle.hdllib.PublicKeyAuthenticationInfo;
import net.handle.hdllib.SessionSetupInfo;
import net.handle.hdllib.Util;

import org.apache.commons.io.IOUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * A class to persist and resolve objects on the Handle Server.
 * 
 */
public class HandleManager extends DefaultPersistenceManager {

  // Handle will not change their url easily, because many users depend on it.
  private static final String PERSISTENT_URL_PREFIX = "http://hdl.handle.net/%s/%s";
  private static final Logger LOG = LoggerFactory.getLogger(HandleManager.class);

  /**
   * Returns a new <code>HandleManager</code>.
   * For more information http://handle.net/documentation.html
   * @param cypherString the cypher, that is used to allow admin actions.
   * @param namingAuthority the naming authority, used by Handle
   * @param prefix the subscription number of the system.
   * @param pathToPrivateKey the private key is created during the setup of the server.
   * @throws PersistenceManagerCreationException is thrown when the private key cannot be found.
   */
  public static HandleManager newHandleManager(String cypherString, String namingAuthority, String prefix, String pathToPrivateKey) throws PersistenceManagerCreationException {
    String cipherString = cypherString;
    byte[] cipher = cipherString.getBytes();
    byte[] privateKeyBytes = readPrivateKey(pathToPrivateKey);
    String authority = namingAuthority;
    String adminHandle = getAdminHandle(authority, prefix);

    PublicKeyAuthenticationInfo authenticationInfo = null;
    SessionSetupInfo sessionSetupInfo = null;
    ClientSessionTracker sessionTracker = new ClientSessionTracker();

    try {
      byte[] decryptedKeyBytes = Util.decrypt(privateKeyBytes, cipher);
      PrivateKey privateKey = Util.getPrivateKeyFromBytes(decryptedKeyBytes, 0);
      authenticationInfo = new PublicKeyAuthenticationInfo(Util.encodeString(adminHandle), 300, privateKey);
      sessionSetupInfo = new SessionSetupInfo();
    } catch (Exception ex) {
      LOG.error("Initialization of handle manager failed: ", ex);
      LOG.error(ex.getMessage());
      throw new PersistenceManagerCreationException(ex);
    }

    sessionTracker.setSessionSetupInfo(sessionSetupInfo);
    HandleResolver resolver = new HandleResolver();
    resolver.setSessionTracker(sessionTracker);

    net.handle.hdllib.Configuration configuration = resolver.getConfiguration();
    //This seems to speed up the communication with the handle server.
    //TODO: Check what this option is doing.
    configuration.setResolutionMethod(net.handle.hdllib.Configuration.RM_WITH_CACHE);

    return new HandleManager(resolver, prefix, authority, authenticationInfo);
  }

  private static byte[] readPrivateKey(String pathToPrivateKey) {
    InputStream inputStream = null;
    try {
      inputStream = getInputStream(pathToPrivateKey);

      byte[] privateKey = IOUtils.toByteArray(inputStream);

      inputStream.close();

      return privateKey;

    } catch (IOException e) {
      LOG.error(e.getMessage());
      return null;
    }

  }

  private static InputStream getInputStream(String pathToPrivateKey) {
    InputStream inputStream = null;

    File file = new File(pathToPrivateKey);

    if (file.exists()) {
      LOG.info("Found location of private key: {}", file.getAbsolutePath());

      try {
        inputStream = new FileInputStream(file);
      } catch (FileNotFoundException e) {
        // TODO Auto-generated catch block
        e.printStackTrace();
      }
    } else {
      inputStream = Thread.currentThread().getContextClassLoader().getResourceAsStream(pathToPrivateKey);
    }

    return inputStream;
  }

  private static String getAdminHandle(String namingAuthority, String prefix) {
    return namingAuthority + "/" + prefix;
  }

  // -------------------------------------------------------------------

  private final HandleResolver handleResolver;
  private final String namingAuthority;
  private final String prefix;
  private final AuthenticationInfo authenticationInfo;

  public HandleManager(HandleResolver resolver, String prefix, String namingAuthority,
                       AuthenticationInfo authenticationInfo) {
    handleResolver = resolver;
    this.prefix = prefix;
    this.namingAuthority = namingAuthority;
    this.authenticationInfo = authenticationInfo;
  }

  @Override
  public String getPersistedURL(String persistenceID) throws PersistenceException {
    String url = null;
    String handleName = createHandleName(persistenceID);

    try {
      HandleValue[] values = handleResolver.resolveHandle(handleName, new String[] { "URL" }, new int[] { 1 });
      if (values != null) {
        url = values[0].getDataAsString();
      }
    } catch (HandleException ex) {
      throw new PersistenceException(ex);
    }

    return url;
  }

  @Override
  public String getPersistentURL(String persistentId) {

    return String.format(PERSISTENT_URL_PREFIX, prefix, persistentId);
  }

  @Override
  public String persistURL(String url) throws PersistenceException {
    String id = createId();

    HandleValue urlValue = createHandleValue(url);

    HandleValue adminValue = null;
    try {
      adminValue = createAdminValue(createAdminHandle(), 200, 100);
      HandleValue[] handleValues = { urlValue, adminValue };
      String handleName = createHandleName(id);

      AuthenticationInfo authInfo = createAuthenticationInfo();

      CreateHandleRequest createRequest = new CreateHandleRequest(Util.encodeString(handleName), handleValues, authInfo);

      handleResolver.processRequest(createRequest);

    } catch (HandleException ex) {
      throw new PersistenceException(ex);
    }

    return id;
  }

  private HandleValue createHandleValue(String url) {
    HandleValue urlValue = new HandleValue(1, Util.encodeString("URL"), Util.encodeString(url));
    urlValue.setAdminCanRead(true);
    urlValue.setAdminCanWrite(true);
    urlValue.setAnyoneCanRead(true);
    urlValue.setAnyoneCanWrite(false);
    return urlValue;
  }

  private AuthenticationInfo createAuthenticationInfo() {
    return this.authenticationInfo;
  }

  @Override
  public void modifyURLForPersistentId(String persistentId, String url) throws PersistenceException {
    HandleValue urlValue = createHandleValue(url);
    HandleValue adminValue = null;
    try {
      adminValue = createAdminValue(createAdminHandle(), 200, 100);
      HandleValue[] handleValues = { urlValue, adminValue };
      String handleName = createHandleName(persistentId);

      AuthenticationInfo authInfo = createAuthenticationInfo();

      ModifyValueRequest modifyRequest = new ModifyValueRequest(Util.encodeString(handleName), handleValues, authInfo);

      handleResolver.processRequest(modifyRequest);

    } catch (HandleException ex) {
      throw new PersistenceException(ex);
    }

  }

  @Override
  public void deletePersistentId(String pid) throws PersistenceException {
    String handleName = createHandleName(pid);
    try {
      AuthenticationInfo authInfo = createAuthenticationInfo();
      DeleteHandleRequest deleteRequest = new DeleteHandleRequest(Util.encodeString(handleName), authInfo);
      AbstractResponse response = handleResolver.processRequest(deleteRequest);
      // do something with the response?

    } catch (HandleException ex) {
      throw new PersistenceException(ex);
    }
  }

  public HandleValue createAdminValue(final String adminHandle, final int keyIndex, int index) throws HandleException {
    AdminRecord adminRecord = new AdminRecord(Util.encodeString(adminHandle), keyIndex, true, true, true, true, true, true, true, true, true, true, true, true);
    return new HandleValue(index, Common.ADMIN_TYPE, Encoder.encodeAdminRecord(adminRecord), HandleValue.TTL_TYPE_RELATIVE, 86400, 0, null, true, true, true, false);
  }

  private String createAdminHandle() {
    return namingAuthority + "/" + prefix;
  }

  private String createHandleName(String id) {
    return prefix + "/" + id;
  }

}
