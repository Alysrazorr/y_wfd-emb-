package nl.knaw.huygens.persistence;

public class PersistenceManagerCreationException extends Exception {

  /**
   * 
   */
  private static final long serialVersionUID = 1L;

  public PersistenceManagerCreationException(String message) {
    super(message);
  }

  public PersistenceManagerCreationException(String message, Throwable cause) {
    super(message, cause);
  }

  public PersistenceManagerCreationException(Throwable cause) {
    super(cause);
  }

}
