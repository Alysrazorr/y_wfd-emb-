package nl.knaw.huygens.timbuctoo.remote.rs.download;

import com.google.common.base.MoreObjects;
import com.google.errorprone.annotations.CanIgnoreReturnValue;
import com.google.errorprone.annotations.Var;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import javax.annotation.CheckReturnValue;
import javax.annotation.Nullable;
import javax.annotation.ParametersAreNonnullByDefault;
import javax.annotation.concurrent.Immutable;
import javax.annotation.concurrent.NotThreadSafe;
import org.immutables.value.Generated;

/**
 * Immutable implementation of {@link RemoteFile}.
 * <p>
 * Use the builder to create immutable instances:
 * {@code ImmutableRemoteFile.builder()}.
 */
@Generated(from = "RemoteFile", generator = "Immutables")
@SuppressWarnings({"all"})
@ParametersAreNonnullByDefault
@javax.annotation.processing.Generated("org.immutables.processor.ProxyProcessor")
@Immutable
@CheckReturnValue
public final class ImmutableRemoteFile implements RemoteFile {
  private final String url;
  private final RemoteFile.RemoteData data;
  private final String mimeType;
  private final Metadata metadata;

  private ImmutableRemoteFile(
      String url,
      RemoteFile.RemoteData data,
      String mimeType,
      Metadata metadata) {
    this.url = url;
    this.data = data;
    this.mimeType = mimeType;
    this.metadata = metadata;
  }

  /**
   * @return The value of the {@code url} attribute
   */
  @Override
  public String getUrl() {
    return url;
  }

  /**
   * @return The value of the {@code data} attribute
   */
  @Override
  public RemoteFile.RemoteData getData() {
    return data;
  }

  /**
   * @return The value of the {@code mimeType} attribute
   */
  @Override
  public String getMimeType() {
    return mimeType;
  }

  /**
   * @return The value of the {@code metadata} attribute
   */
  @Override
  public Metadata getMetadata() {
    return metadata;
  }

  /**
   * Copy the current immutable object by setting a value for the {@link RemoteFile#getUrl() url} attribute.
   * An equals check used to prevent copying of the same value by returning {@code this}.
   * @param value A new value for url
   * @return A modified copy of the {@code this} object
   */
  public final ImmutableRemoteFile withUrl(String value) {
    String newValue = Objects.requireNonNull(value, "url");
    if (this.url.equals(newValue)) return this;
    return new ImmutableRemoteFile(newValue, this.data, this.mimeType, this.metadata);
  }

  /**
   * Copy the current immutable object by setting a value for the {@link RemoteFile#getData() data} attribute.
   * A shallow reference equality check is used to prevent copying of the same value by returning {@code this}.
   * @param value A new value for data
   * @return A modified copy of the {@code this} object
   */
  public final ImmutableRemoteFile withData(RemoteFile.RemoteData value) {
    if (this.data == value) return this;
    RemoteFile.RemoteData newValue = Objects.requireNonNull(value, "data");
    return new ImmutableRemoteFile(this.url, newValue, this.mimeType, this.metadata);
  }

  /**
   * Copy the current immutable object by setting a value for the {@link RemoteFile#getMimeType() mimeType} attribute.
   * An equals check used to prevent copying of the same value by returning {@code this}.
   * @param value A new value for mimeType
   * @return A modified copy of the {@code this} object
   */
  public final ImmutableRemoteFile withMimeType(String value) {
    String newValue = Objects.requireNonNull(value, "mimeType");
    if (this.mimeType.equals(newValue)) return this;
    return new ImmutableRemoteFile(this.url, this.data, newValue, this.metadata);
  }

  /**
   * Copy the current immutable object by setting a value for the {@link RemoteFile#getMetadata() metadata} attribute.
   * A shallow reference equality check is used to prevent copying of the same value by returning {@code this}.
   * @param value A new value for metadata
   * @return A modified copy of the {@code this} object
   */
  public final ImmutableRemoteFile withMetadata(Metadata value) {
    if (this.metadata == value) return this;
    Metadata newValue = Objects.requireNonNull(value, "metadata");
    return new ImmutableRemoteFile(this.url, this.data, this.mimeType, newValue);
  }

  /**
   * This instance is equal to all instances of {@code ImmutableRemoteFile} that have equal attribute values.
   * @return {@code true} if {@code this} is equal to {@code another} instance
   */
  @Override
  public boolean equals(@Nullable Object another) {
    if (this == another) return true;
    return another instanceof ImmutableRemoteFile
        && equalTo((ImmutableRemoteFile) another);
  }

  private boolean equalTo(ImmutableRemoteFile another) {
    return url.equals(another.url)
        && data.equals(another.data)
        && mimeType.equals(another.mimeType)
        && metadata.equals(another.metadata);
  }

  /**
   * Computes a hash code from attributes: {@code url}, {@code data}, {@code mimeType}, {@code metadata}.
   * @return hashCode value
   */
  @Override
  public int hashCode() {
    @Var int h = 5381;
    h += (h << 5) + url.hashCode();
    h += (h << 5) + data.hashCode();
    h += (h << 5) + mimeType.hashCode();
    h += (h << 5) + metadata.hashCode();
    return h;
  }

  /**
   * Prints the immutable value {@code RemoteFile} with attribute values.
   * @return A string representation of the value
   */
  @Override
  public String toString() {
    return MoreObjects.toStringHelper("RemoteFile")
        .omitNullValues()
        .add("url", url)
        .add("data", data)
        .add("mimeType", mimeType)
        .add("metadata", metadata)
        .toString();
  }

  /**
   * Creates an immutable copy of a {@link RemoteFile} value.
   * Uses accessors to get values to initialize the new immutable instance.
   * If an instance is already immutable, it is returned as is.
   * @param instance The instance to copy
   * @return A copied immutable RemoteFile instance
   */
  public static ImmutableRemoteFile copyOf(RemoteFile instance) {
    if (instance instanceof ImmutableRemoteFile) {
      return (ImmutableRemoteFile) instance;
    }
    return ImmutableRemoteFile.builder()
        .from(instance)
        .build();
  }

  /**
   * Creates a builder for {@link ImmutableRemoteFile ImmutableRemoteFile}.
   * <pre>
   * ImmutableRemoteFile.builder()
   *    .url(String) // required {@link RemoteFile#getUrl() url}
   *    .data(nl.knaw.huygens.timbuctoo.remote.rs.download.RemoteFile.RemoteData) // required {@link RemoteFile#getData() data}
   *    .mimeType(String) // required {@link RemoteFile#getMimeType() mimeType}
   *    .metadata(nl.knaw.huygens.timbuctoo.remote.rs.download.Metadata) // required {@link RemoteFile#getMetadata() metadata}
   *    .build();
   * </pre>
   * @return A new ImmutableRemoteFile builder
   */
  public static ImmutableRemoteFile.Builder builder() {
    return new ImmutableRemoteFile.Builder();
  }

  /**
   * Builds instances of type {@link ImmutableRemoteFile ImmutableRemoteFile}.
   * Initialize attributes and then invoke the {@link #build()} method to create an
   * immutable instance.
   * <p><em>{@code Builder} is not thread-safe and generally should not be stored in a field or collection,
   * but instead used immediately to create instances.</em>
   */
  @Generated(from = "RemoteFile", generator = "Immutables")
  @NotThreadSafe
  public static final class Builder {
    private static final long INIT_BIT_URL = 0x1L;
    private static final long INIT_BIT_DATA = 0x2L;
    private static final long INIT_BIT_MIME_TYPE = 0x4L;
    private static final long INIT_BIT_METADATA = 0x8L;
    private long initBits = 0xfL;

    private @Nullable String url;
    private @Nullable RemoteFile.RemoteData data;
    private @Nullable String mimeType;
    private @Nullable Metadata metadata;

    private Builder() {
    }

    /**
     * Fill a builder with attribute values from the provided {@code RemoteFile} instance.
     * Regular attribute values will be replaced with those from the given instance.
     * Absent optional values will not replace present values.
     * @param instance The instance from which to copy values
     * @return {@code this} builder for use in a chained invocation
     */
    @CanIgnoreReturnValue 
    public final Builder from(RemoteFile instance) {
      Objects.requireNonNull(instance, "instance");
      url(instance.getUrl());
      data(instance.getData());
      mimeType(instance.getMimeType());
      metadata(instance.getMetadata());
      return this;
    }

    /**
     * Initializes the value for the {@link RemoteFile#getUrl() url} attribute.
     * @param url The value for url 
     * @return {@code this} builder for use in a chained invocation
     */
    @CanIgnoreReturnValue 
    public final Builder url(String url) {
      this.url = Objects.requireNonNull(url, "url");
      initBits &= ~INIT_BIT_URL;
      return this;
    }

    /**
     * Initializes the value for the {@link RemoteFile#getData() data} attribute.
     * @param data The value for data 
     * @return {@code this} builder for use in a chained invocation
     */
    @CanIgnoreReturnValue 
    public final Builder data(RemoteFile.RemoteData data) {
      this.data = Objects.requireNonNull(data, "data");
      initBits &= ~INIT_BIT_DATA;
      return this;
    }

    /**
     * Initializes the value for the {@link RemoteFile#getMimeType() mimeType} attribute.
     * @param mimeType The value for mimeType 
     * @return {@code this} builder for use in a chained invocation
     */
    @CanIgnoreReturnValue 
    public final Builder mimeType(String mimeType) {
      this.mimeType = Objects.requireNonNull(mimeType, "mimeType");
      initBits &= ~INIT_BIT_MIME_TYPE;
      return this;
    }

    /**
     * Initializes the value for the {@link RemoteFile#getMetadata() metadata} attribute.
     * @param metadata The value for metadata 
     * @return {@code this} builder for use in a chained invocation
     */
    @CanIgnoreReturnValue 
    public final Builder metadata(Metadata metadata) {
      this.metadata = Objects.requireNonNull(metadata, "metadata");
      initBits &= ~INIT_BIT_METADATA;
      return this;
    }

    /**
     * Builds a new {@link ImmutableRemoteFile ImmutableRemoteFile}.
     * @return An immutable instance of RemoteFile
     * @throws java.lang.IllegalStateException if any required attributes are missing
     */
    public ImmutableRemoteFile build() {
      if (initBits != 0) {
        throw new IllegalStateException(formatRequiredAttributesMessage());
      }
      return new ImmutableRemoteFile(url, data, mimeType, metadata);
    }

    private String formatRequiredAttributesMessage() {
      List<String> attributes = new ArrayList<>();
      if ((initBits & INIT_BIT_URL) != 0) attributes.add("url");
      if ((initBits & INIT_BIT_DATA) != 0) attributes.add("data");
      if ((initBits & INIT_BIT_MIME_TYPE) != 0) attributes.add("mimeType");
      if ((initBits & INIT_BIT_METADATA) != 0) attributes.add("metadata");
      return "Cannot build RemoteFile, some of required attributes are not set " + attributes;
    }
  }
}
